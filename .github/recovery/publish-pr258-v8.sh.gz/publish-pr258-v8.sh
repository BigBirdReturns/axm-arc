#!/usr/bin/env bash
set -euo pipefail

mkdir -p "$RECEIPT_ROOT" "$SOURCE_ROOT" "$UNPACK_ROOT"
stage=initialize
published=false
candidate_sha=''

finalize() {
  rc=$?
  mkdir -p "$RECEIPT_ROOT"
  printf '%s\n' "$stage" > "$RECEIPT_ROOT/stage.txt"
  printf '%s\n' \
    "carrierSha=$GITHUB_SHA" \
    "baseSha=$BASE_SHA" \
    "targetBranch=$TARGET_BRANCH" \
    "published=$published" \
    "exitCode=$rc" \
    > "$RECEIPT_ROOT/publication-boundary.txt"
  if test -n "$candidate_sha"; then
    printf '%s\n' "$candidate_sha" > "$RECEIPT_ROOT/candidate-sha.txt"
  fi
  find "$RECEIPT_ROOT" -type f ! -name SHA256SUMS -print0 \
    | sort -z \
    | xargs -0 sha256sum \
    | sed "s#  $RECEIPT_ROOT/#  #" \
    > "$RECEIPT_ROOT/SHA256SUMS" || true
  exit "$rc"
}
trap finalize EXIT

stage=verify-carrier
printf '%s\n' "$GITHUB_SHA" > "$RECEIPT_ROOT/carrier-sha.txt"
printf '%s\n' "$BASE_SHA" > "$RECEIPT_ROOT/base-sha.txt"

cat > "$RECEIPT_ROOT/chunk-ledger.tsv" <<'EOF'
.github/recovery-chunks/pr258/part-00.bin	022cbab35455bf546c610ee88e5fb7fe895331c0	4096	ccd5b269f34c63ac34eafd69567362db7e8319b0aa13dc51b9d324673253b70f
.github/recovery-chunks/pr258/part-01.bin	d28b0016d13448f8e09e7b401953873dc2645b82	4096	d6e2a3f420c94a761421443b24bc207f93d04268aa83afeb82fd80abfd560f94
.github/recovery-chunks/pr258/part-02.bin	3d08dd42ef76fbecaaec34bab4e7d4818f992bba	4096	481948bd86d23fb22b8525f185a69b157c157e3ccf0b3a9350f2f982db79a5f0
.github/recovery-chunks/pr258/part-03.bin	2ef0982901a408c9632ba266dd7ec9a386ce5902	4096	b1c58a6b5b919c68a8bccbe90ca85e4b08df4d65ca57f2682cb86f212bf710ef
.github/recovery-chunks/pr258/part-04.bin	770cce53ad3b5d28e7873213a0c3071b23fdc55f	4096	b024dc09a90f14e6e3226d11263744942a7a946d2246ed9e6b7b0e16473dd1bd
.github/recovery-chunks/pr258/part-05.bin	3d360cd295076893a6142fa99835b9c2b4d5f97c	4096	6e1d344b137610078de1b6bdb28de2d6ed314c24bf61311e90eefa7a2697d1d2
.github/recovery-chunks/pr258/part-06.bin	bd9b2d93ac2875ff706918ef55efa9bfe1504e90	4096	ef492f2c9a460160020c8d9c4069a93fbf3e3f0d211ef8393d022df091c8e41a
.github/recovery-chunks/pr258/part-07.bin	2ca95f1f5632eb565dffbae06245d77c1cd60497	4096	0be3a74ac3946c6a42a1126ccebd619333823e8dc47bde6e85ede4fec4ddfa35
.github/recovery-chunks/pr258/part-08.bin	247d90b5345a3c462dab11888ecea1f5fa9f7b1b	4096	03e3ae316f2f0a270c24d37200af0955c7fdd21a2dc75a9fd38237d238e6ed09
.github/recovery-chunks/pr258/part-09.bin	674deb05f773f8140e0a819cdf42d8c997688b68	4096	f5be213736854d02e9bbed7219dcf4dc120de3b63bfea0e38b4aa429c3a39b50
.github/recovery-chunks/pr258/part-10.bin	239236dadbdcef314b20b8bceee7b04b49c37673	4096	8fa6ceeeb23f55f1b6b7ff261ffd0d859874753184707368db0eae339acd36db
.github/recovery-chunks/pr258/part-11.bin	89d182f78d30147bac76dc7449c6d78799c6fe45	677	5332bf661de9216e7eae02dd60adb7bf54531c30cf2afe85052de027f81bc0c8
EOF

cat > "$RECEIPT_ROOT/expected-carrier-paths.txt" <<'EOF'
.github/recovery-chunks/pr258/part-00.bin
.github/recovery-chunks/pr258/part-01.bin
.github/recovery-chunks/pr258/part-02.bin
.github/recovery-chunks/pr258/part-03.bin
.github/recovery-chunks/pr258/part-04.bin
.github/recovery-chunks/pr258/part-05.bin
.github/recovery-chunks/pr258/part-06.bin
.github/recovery-chunks/pr258/part-07.bin
.github/recovery-chunks/pr258/part-08.bin
.github/recovery-chunks/pr258/part-09.bin
.github/recovery-chunks/pr258/part-10.bin
.github/recovery-chunks/pr258/part-11.bin
.github/recovery/publish-pr258-v8.sh.gz
.github/workflows/.publish-carrier-free-supervised-delivery-v8.trigger
.github/workflows/publish-carrier-free-asoiaf-supervised-delivery-v8.yml
EOF
sort -o "$RECEIPT_ROOT/expected-carrier-paths.txt" "$RECEIPT_ROOT/expected-carrier-paths.txt"
git ls-tree -r --name-only HEAD | sort > "$RECEIPT_ROOT/actual-carrier-paths.txt"
diff -u "$RECEIPT_ROOT/expected-carrier-paths.txt" "$RECEIPT_ROOT/actual-carrier-paths.txt"

: > "$ARCHIVE_PATH"
index=0
while IFS=$'\t' read -r path expected_blob expected_bytes expected_sha256; do
  test -f "$path"
  test "$(git rev-parse "HEAD:$path")" = "$expected_blob"
  test "$(git hash-object "$path")" = "$expected_blob"
  test "$(wc -c < "$path" | tr -d ' ')" = "$expected_bytes"
  test "$(sha256sum "$path" | awk '{print $1}')" = "$expected_sha256"
  cat "$path" >> "$ARCHIVE_PATH"
  index=$((index + 1))
done < "$RECEIPT_ROOT/chunk-ledger.tsv"
test "$index" = 12
test "$(wc -c < "$ARCHIVE_PATH" | tr -d ' ')" = "$ARCHIVE_BYTES"
test "$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')" = "$ARCHIVE_SHA256"
test "$(git hash-object "$ARCHIVE_PATH")" = "$ARCHIVE_GIT_BLOB"
unzip -t "$ARCHIVE_PATH" | tee "$RECEIPT_ROOT/archive-integrity.log"
unzip -q "$ARCHIVE_PATH" -d "$UNPACK_ROOT"

stage=verify-candidate
candidate="$UNPACK_ROOT/PR258_carrier_free_recovery_candidate"
test -d "$candidate/source"
(cd "$candidate" && sha256sum --check --strict SHA256SUMS) \
  | tee "$RECEIPT_ROOT/candidate-sha256-verification.log"
cp "$candidate/MANIFEST.json" "$RECEIPT_ROOT/source-manifest.json"
cp "$candidate/SHA256SUMS" "$RECEIPT_ROOT/source-SHA256SUMS"

manifest="$candidate/MANIFEST.json"
test "$(jq -r .format "$manifest")" = 'axm-asoiaf-answer-supervised-delivery-recovery-candidate/1'
test "$(jq -r .repository "$manifest")" = "$GITHUB_REPOSITORY"
test "$(jq -r .baseHead "$manifest")" = "$BASE_SHA"
test "$(jq -r .intendedBranch "$manifest")" = 'recovery/asoiaf-answer-desk-supervised-delivery-v1'
test "$(jq -r .permanentSurfaceCount "$manifest")" = 7
test "$(jq '.permanentSurfaces | length' "$manifest")" = 7

jq -r '.permanentSurfaces[].path' "$manifest" | sort > "$RECEIPT_ROOT/expected-paths.txt"
cat > "$RECEIPT_ROOT/canonical-paths.txt" <<'EOF'
.github/workflows/asoiaf-answer-desk-supervised-delivery.yml
docs/ASOIAF_ANSWER_DESK_SUPERVISED_DELIVERY.md
package.json
tests/fixtures/emit-asoiaf-answer-desk-supervised-delivery-input.ts
tests/narrative/canon/asoiaf-answer-desk-supervised-delivery.test.ts
tools/asoiaf-answer-desk-supervised-delivery.ts
tools/lib/asoiaf-answer-desk-supervised-delivery.ts
EOF
sort -o "$RECEIPT_ROOT/canonical-paths.txt" "$RECEIPT_ROOT/canonical-paths.txt"
diff -u "$RECEIPT_ROOT/canonical-paths.txt" "$RECEIPT_ROOT/expected-paths.txt"

while IFS=$'\t' read -r path expected_sha expected_blob expected_bytes; do
  source="$candidate/source/$path"
  test -f "$source"
  test "sha256:$(sha256sum "$source" | awk '{print $1}')" = "$expected_sha"
  test "$(git hash-object "$source")" = "$expected_blob"
  test "$(wc -c < "$source" | tr -d ' ')" = "$expected_bytes"
  target="$SOURCE_ROOT/$path"
  mkdir -p "$(dirname "$target")"
  cp "$source" "$target"
done < <(jq -r '.permanentSurfaces[] | [.path,.sha256,.gitBlobSha1,(.bytes|tostring)] | @tsv' "$manifest")

stage=resolve-target
git fetch --force origin \
  "+refs/heads/$BASE_BRANCH:refs/remotes/origin/$BASE_BRANCH" \
  "+refs/heads/$TARGET_BRANCH:refs/remotes/origin/$TARGET_BRANCH"
test "$(git rev-parse refs/remotes/origin/$BASE_BRANCH)" = "$BASE_SHA"

gh api "repos/$GITHUB_REPOSITORY/pulls/$PR_NUMBER" > "$RECEIPT_ROOT/pr-before.json"
test "$(jq -r .state "$RECEIPT_ROOT/pr-before.json")" = open
test "$(jq -r .draft "$RECEIPT_ROOT/pr-before.json")" = true
test "$(jq -r .merged "$RECEIPT_ROOT/pr-before.json")" = false
test "$(jq -r .base.ref "$RECEIPT_ROOT/pr-before.json")" = "$BASE_BRANCH"
test "$(jq -r .base.sha "$RECEIPT_ROOT/pr-before.json")" = "$BASE_SHA"
test "$(jq -r .head.ref "$RECEIPT_ROOT/pr-before.json")" = "$TARGET_BRANCH"
replaced_head="$(jq -r .head.sha "$RECEIPT_ROOT/pr-before.json")"
test -n "$replaced_head"
test "$(git rev-parse refs/remotes/origin/$TARGET_BRANCH)" = "$replaced_head"
git merge-base --is-ancestor "$BASE_SHA" "$replaced_head"
printf '%s\n' "$replaced_head" > "$RECEIPT_ROOT/replaced-head.txt"

stage=construct-commit
git checkout --detach "$BASE_SHA"
test "$(git rev-parse HEAD)" = "$BASE_SHA"
while IFS=$'\t' read -r path expected_sha expected_blob expected_bytes; do
  source="$SOURCE_ROOT/$path"
  test -f "$source"
  mkdir -p "$(dirname "$path")"
  cp "$source" "$path"
  test "sha256:$(sha256sum "$path" | awk '{print $1}')" = "$expected_sha"
  test "$(git hash-object "$path")" = "$expected_blob"
  test "$(wc -c < "$path" | tr -d ' ')" = "$expected_bytes"
done < <(jq -r '.permanentSurfaces[] | [.path,.sha256,.gitBlobSha1,(.bytes|tostring)] | @tsv' "$manifest")

git add -A
git diff --cached --check
git diff --cached --name-only "$BASE_SHA" -- | sort > "$RECEIPT_ROOT/actual-paths.txt"
diff -u "$RECEIPT_ROOT/expected-paths.txt" "$RECEIPT_ROOT/actual-paths.txt"
if grep -Ei -- '(^|/)[^/]*\.(key|pem|p12|pfx|csr|crt)$' "$RECEIPT_ROOT/expected-paths.txt"; then
  echo 'permanent surface path is secret-bearing' >&2
  exit 1
fi

git config user.name 'github-actions[bot]'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
GIT_AUTHOR_DATE='2026-08-06T00:00:00Z' \
GIT_COMMITTER_DATE='2026-08-06T00:00:00Z' \
  git commit -m 'Restore certificate-authenticated ASOIAF supervised delivery'
candidate_sha="$(git rev-parse HEAD)"
test "$(git show -s --format=%P HEAD)" = "$BASE_SHA"
test -z "$(git status --porcelain --untracked-files=all)"
while IFS=$'\t' read -r path _ expected_blob _; do
  test "$(git rev-parse "HEAD:$path")" = "$expected_blob"
done < <(jq -r '.permanentSurfaces[] | [.path,.sha256,.gitBlobSha1,(.bytes|tostring)] | @tsv' "$manifest")
printf '%s\n' "$candidate_sha" > "$RECEIPT_ROOT/candidate-sha.txt"
git diff --name-status "$BASE_SHA" "$candidate_sha" > "$RECEIPT_ROOT/final-diff.txt"

stage=publish
for attempt in $(seq 1 8); do
  gh api "repos/$GITHUB_REPOSITORY/pulls/$PR_NUMBER" > "$RECEIPT_ROOT/pr-publish-$attempt.json"
  test "$(jq -r .state "$RECEIPT_ROOT/pr-publish-$attempt.json")" = open
  test "$(jq -r .draft "$RECEIPT_ROOT/pr-publish-$attempt.json")" = true
  test "$(jq -r .merged "$RECEIPT_ROOT/pr-publish-$attempt.json")" = false
  test "$(jq -r .base.ref "$RECEIPT_ROOT/pr-publish-$attempt.json")" = "$BASE_BRANCH"
  test "$(jq -r .base.sha "$RECEIPT_ROOT/pr-publish-$attempt.json")" = "$BASE_SHA"
  test "$(jq -r .head.ref "$RECEIPT_ROOT/pr-publish-$attempt.json")" = "$TARGET_BRANCH"
  current_head="$(jq -r .head.sha "$RECEIPT_ROOT/pr-publish-$attempt.json")"
  test -n "$current_head"
  if test "$current_head" = "$candidate_sha"; then
    published=true
    break
  fi
  git fetch --force origin "+refs/heads/$TARGET_BRANCH:refs/remotes/origin/$TARGET_BRANCH"
  test "$(git rev-parse refs/remotes/origin/$TARGET_BRANCH)" = "$current_head"
  git merge-base --is-ancestor "$BASE_SHA" "$current_head"
  if git push \
    --force-with-lease="refs/heads/$TARGET_BRANCH:$current_head" \
    origin "$candidate_sha:refs/heads/$TARGET_BRANCH"; then
    published=true
    break
  fi
  sleep 2
done
test "$published" = true

git fetch --force origin "+refs/heads/$TARGET_BRANCH:refs/remotes/origin/$TARGET_BRANCH"
test "$(git rev-parse refs/remotes/origin/$TARGET_BRANCH)" = "$candidate_sha"
printf '%s\n' true > "$RECEIPT_ROOT/published.txt"
stage=published
